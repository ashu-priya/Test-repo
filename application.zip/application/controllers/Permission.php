<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Permission extends CI_Controller {

    function __construct() {
        parent::__construct();
        $this->load->model('Main_model');

        $this->custom->initialise_session();
        $this->custom->login_redirect();
        // $this->check_permission->load_user_acl($_SESSION['role_id']);
    }

    public function add($table = '') {

        $this->load->view("Permission/add_" . $table);
    }

    public function set($table, $id = '') {
        if ($table == "hospital_holiday") {
            $_POST['date'] = date('Y-m-d', strtotime($_POST['date']));
        }
        $multiple_table = 0;
        if ((isset($_POST['child'][0]['table'])) || (isset($_POST['child'][1]['table']))) {//handling secondary table data
            $multiple_table = 1;
            foreach ($_POST['children'] as $key => $table_data) {
                $records[$key]['data'] = $table_data;
                $records[$key]['table'] = $_POST['child'][$key]['table'];
                $records[$key]['foreign_id'] = $_POST['child'][$key]['foreign_id'];
            }
            unset($_POST['child']);
            unset($_POST['children']);
        }
        //for multiple table insert/update
        switch ($table) {




            case 'roles':
                if ($id) {
                    $_POST['modify_by'] = $_SESSION['user_id'];
                    $this->Main_model->add_update_record($table, $_POST, "id");
                } else {
                    $_POST['created_date'] = date("Y-m-d H:i:s");
                    ;
                    $_POST['created_by'] = $_SESSION['user_id'];
                    $id = $this->Main_model->add_update_record($table, $_POST);
                    $_POST['id'] = $id;
                }
                break;
            case 'permission_groups':
                if ($id) {
                    $_POST['modify_by'] = $_SESSION['user_id'];
                    $this->Main_model->add_update_record($table, $_POST, "id");
                } else {
                    $_POST['created_date'] = date("Y-m-d H:i:s");
                    ;
                    $_POST['created_by'] = $_SESSION['user_id'];
                    $id = $this->Main_model->add_update_record($table, $_POST);
                    $_POST['id'] = $id;
                }
                break;
            case 'control_points':
                if ($id) {
                    $_POST['modify_by'] = $_SESSION['user_id'];
                    $this->Main_model->add_update_record($table, $_POST, "id");
                } else {
                    $_POST['created_date'] = date("Y-m-d H:i:s");
                    ;
                    $_POST['created_by'] = $_SESSION['user_id'];
                    $id = $this->Main_model->add_update_record($table, $_POST);
                    $_POST['id'] = $id;
                }
                break;
        }//end of switch.
        if ($multiple_table) {//for updating records in child table with foreign key
            foreach ($records as $key => $tables) {
                $this->main_model->add_update_many_records($tables['table'], $tables['data'], $tables['foreign_id'], $_POST['id']);
            }
        }//end for multiple table
        $this->manage($table);
    }

    public function manage($table = '') {
        $result['DATA'] = $this->Main_model->get_records($table);
        if ($result['DATA']) {
            $this->load->view("Permission/manage_" . $table, $result);
        } else {
            $this->load->view("Permission/manage_" . $table);
        }
    }

    public function edit($table = '', $id = 0) {//for add/update form
        $row_data['data'] = $this->Main_model->get_records_for_edit($table, 'id', $id);
//===============conditional reading child data from linked tables


        $this->load->view('Permission/edit_' . $table, $row_data);
    }

    public function delete($table = '', $id = 0) {
        $this->Main_model->my_delete_record($table, "id", $id);
        header('Location: ' . base_url() . "Permission/manage/" . $table);
    }

    public function assign($table = '', $id = 0) {
        $tmp = explode('-', $table);
        $assigned_to_tbl = end($tmp);
//        $assigned_to_tbl = end(explode('-', $table));
//        echo '<pre>';
//        print_r($id);
//        die;
        $array_values = explode('-', $table);
        $assigned_from_tbl = $array_values[0];
        $filter_fields[0]['id'] = $assigned_to_tbl;
        $filter_fields[0]['value'] = $id;

        $request_fields[0] = $assigned_from_tbl;
        $assigned_items = $this->Main_model->get_many_records($table, $filter_fields, $request_fields, "");
        $source_data = array();


        if ($assigned_items) {
            foreach ($assigned_items as $key => $value) {
                $source_data[$key] = $value[$assigned_from_tbl];
            }
        }
        $data['source_data'] = $source_data;
        $this->load->view('Permission/assign_' . $table, $data);
    }

    public function set_many($table = '', $id = '') {
//        echo '<pre>';
//        print_r($table);
//        die;
        $tmp = explode('-', $table);
        $assigned_to_tbl = end($tmp);
//        $assigned_to_tbl = end(explode('-', $table));
        $array_values = explode('-', $table);
        $assigned_from_tbl = $array_values[0];
        if (isset($_POST[$assigned_from_tbl])) {
            $records = $_POST[$assigned_from_tbl];
            $i = 0;
            foreach ($records as $value) {
                $data[$i][$assigned_from_tbl] = $value;
                $data[$i][$assigned_to_tbl] = $id;
                $i++;
            }
        }
//        echo '<pre>';
//        print_r($data);
//        die;
        $this->Main_model->add_update_many_records($table, $data, $assigned_to_tbl, $id); //$assigned_to_tbl--is the repititive field name in one-to-many table


        header('Location: ' . base_url() . 'Permission/manage/' . end(explode('-', $table)));
    }

}
